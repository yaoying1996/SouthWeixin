package com.south.po;


/**
 * �ı���Ϣ
 * @author yao
 *
 */
public class TextMessage extends BaseMessage {
    // �ظ�����Ϣ����
    private String Content;

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }
}