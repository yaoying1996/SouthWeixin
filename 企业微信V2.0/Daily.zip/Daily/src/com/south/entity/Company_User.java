package com.south.entity;

public class Company_User {
	//
	private String company_name;
	
	private int contacts_id;
	
	private String openid;
	
	private String userName;

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public int getContacts_id() {
		return contacts_id;
	}

	public void setContacts_id(int contacts_id) {
		this.contacts_id = contacts_id;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	

	

	
	
}
